#pragma once

#define UNIT_TESTS_NAMESPACE                unit_tests
#define BEGIN_UNIT_TESTS_NAMESPACE          namespace UNIT_TESTS_NAMESPACE {
#define END_UNIT_TESTS_NAMESPACE            }
#define BEGIN_UNNAMED_NAMESPACE             namespace {
#define END_UNNAMED_NAMESPACE               }

#define USING_NAMESPACE_UNIT_TESTS            using namespace UNIT_TESTS_NAMESPACE;

BEGIN_UNIT_TESTS_NAMESPACE

END_UNIT_TESTS_NAMESPACE
